package com.easyload.app

import android.app.UiModeManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.net.Uri

object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("easyload", Context.MODE_PRIVATE)

    fun serverUrl(c: Context): String? = sp(c).getString("server", null)
    fun setServer(c: Context, url: String) = sp(c).edit().putString("server", url).apply()

    /** "auto", "phone" or "tv" */
    fun mode(c: Context): String = sp(c).getString("mode", "auto") ?: "auto"
    fun setMode(c: Context, m: String) = sp(c).edit().putString("mode", m).apply()

    fun isTvDevice(c: Context): Boolean {
        val ui = c.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    fun isTvMode(c: Context): Boolean = when (mode(c)) {
        "tv" -> true
        "phone" -> false
        else -> isTvDevice(c)
    }

    fun startOnBoot(c: Context): Boolean = sp(c).getBoolean("boot", isTvDevice(c))
    fun setStartOnBoot(c: Context, v: Boolean) = sp(c).edit().putBoolean("boot", v).apply()

    /** "192.168.1.5" -> "http://192.168.1.5:3000" ; keeps an explicit port / scheme. */
    fun normalize(input: String): String? {
        var s = input.trim().trimEnd('/')
        if (s.isEmpty()) return null
        if (!s.contains("://")) s = "http://$s"
        val u = Uri.parse(s)
        val host = u.host ?: return null
        val scheme = u.scheme ?: "http"
        val port = when {
            u.port != -1 -> u.port
            scheme == "https" -> -1
            else -> 3000
        }
        return if (port == -1) "$scheme://$host" else "$scheme://$host:$port"
    }
}
