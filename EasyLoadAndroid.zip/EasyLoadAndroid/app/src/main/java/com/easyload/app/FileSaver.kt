package com.easyload.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

object FileSaver {
    class Saved(val uri: Uri, val where: String, val mime: String)

    fun save(ctx: Context, rawName: String, rawMime: String?, bytes: ByteArray): Saved? {
        val name = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "download" }
        var mime = rawMime ?: ""
        if (mime.isBlank() || mime == "application/octet-stream") {
            val ext = name.substringAfterLast('.', "").lowercase()
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { mime = it }
        }
        if (mime.isBlank()) mime = "application/octet-stream"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EasyLoad")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return null
                Saved(uri, "Downloads/EasyLoad", mime)
            } else {
                val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return null
                dir.mkdirs()
                var f = File(dir, name)
                if (f.exists()) f = File(dir, System.currentTimeMillis().toString() + "_" + name)
                f.writeBytes(bytes)
                Saved(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f), "Android/data/${ctx.packageName}/files/Download", mime)
            }
        } catch (e: Exception) {
            null
        }
    }
}
