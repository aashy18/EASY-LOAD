package com.easyload.app

import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Finds the Easy Load PC server on the local Wi-Fi / LAN by scanning the /24 subnet(s) of this device. */
class ServerScanner {
    @Volatile private var cancelled = false
    private val ui = Handler(Looper.getMainLooper())

    fun cancel() { cancelled = true }

    private fun post(r: () -> Unit) { ui.post { if (!cancelled) r() } }

    fun scan(port: Int, onFound: (String) -> Unit, onProgress: (Int, Int) -> Unit, onDone: () -> Unit) {
        Thread {
            val ips = ArrayList<String>()
            for (p in localPrefixes()) for (i in 1..254) ips.add("$p.$i")
            val total = ips.size
            if (total == 0) {
                post { onDone() }
                return@Thread
            }
            val pool = Executors.newFixedThreadPool(64)
            val finished = AtomicInteger(0)
            val latch = CountDownLatch(total)
            for (ip in ips) {
                pool.execute {
                    try {
                        if (!cancelled && probe(ip, port)) post { onFound("http://$ip:$port") }
                    } catch (e: Throwable) {
                    } finally {
                        val d = finished.incrementAndGet()
                        if (d % 8 == 0) post { onProgress(d, total) }
                        latch.countDown()
                    }
                }
            }
            latch.await()
            pool.shutdown()
            post { onDone() }
        }.start()
    }

    private fun probe(ip: String, port: Int): Boolean {
        try {
            Socket().use { it.connect(InetSocketAddress(ip, port), 450) }
        } catch (e: Exception) {
            return false
        }
        return check("http://$ip:$port", 2500, true)
    }

    private fun localPrefixes(): List<String> {
        val out = LinkedHashSet<String>()
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return emptyList()
            for (nif in Collections.list(ifs)) {
                if (!nif.isUp || nif.isLoopback) continue
                for (ia in nif.interfaceAddresses) {
                    val a = ia.address
                    if (a is Inet4Address && a.isSiteLocalAddress) {
                        val p = (a.hostAddress ?: "").split(".")
                        if (p.size == 4) out.add("${p[0]}.${p[1]}.${p[2]}")
                    }
                }
            }
        } catch (e: Exception) { }
        return out.toList().take(3)
    }

    companion object {
        /** True when GET base/ answers 200 (and, if requireBrand, looks like the Easy Load page). */
        fun check(base: String, timeoutMs: Int, requireBrand: Boolean): Boolean {
            var c: HttpURLConnection? = null
            try {
                c = URL("$base/").openConnection() as HttpURLConnection
                c.connectTimeout = timeoutMs
                c.readTimeout = timeoutMs
                c.requestMethod = "GET"
                if (c.responseCode != 200) return false
                if (!requireBrand) return true
                val buf = CharArray(8192)
                val n = c.inputStream.bufferedReader().use { it.read(buf) }
                return n > 0 && String(buf, 0, n).contains("EASY-LOAD", ignoreCase = true)
            } catch (e: Exception) {
                return false
            } finally {
                c?.disconnect()
            }
        }
    }
}
