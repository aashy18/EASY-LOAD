package com.easyload.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var offline: View
    private lateinit var offlineMsg: TextView
    private lateinit var progress: ProgressBar
    private var tts: TtsEngine? = null

    var tvMode = false
        private set
    private var baseUrl = ""
    private var baseHost = ""
    private var loadFailed = false
    private var docStartInjected = false
    private var bridgeJs = ""
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastBack = 0L
    private val handler = Handler(Looper.getMainLooper())

    private val retry = Runnable {
        if (::offline.isInitialized && offline.visibility == View.VISIBLE) web.loadUrl(startUrl())
    }

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val server = Prefs.serverUrl(this)
        if (server == null) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }
        baseUrl = server
        baseHost = Uri.parse(server).host ?: ""
        tvMode = Prefs.isTvMode(this)

        setContentView(R.layout.activity_main)
        web = findViewById(R.id.web)
        offline = findViewById(R.id.offline)
        offlineMsg = findViewById(R.id.offlineMsg)
        progress = findViewById(R.id.progress)
        findViewById<Button>(R.id.btnRetry).setOnClickListener { web.loadUrl(startUrl()) }
        findViewById<Button>(R.id.btnChange).setOnClickListener { openSetup() }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (tvMode) hideSystemBars()

        bridgeJs = try { assets.open("bridge.js").bufferedReader().use { it.readText() } } catch (e: Exception) { "" }

        val engine = TtsEngine(this) { id, type, err ->
            if (id >= 0) runOnUiThread {
                if (::web.isInitialized) {
                    web.evaluateJavascript(
                        "window.__elTtsEvent&&window.__elTtsEvent($id,'$type',${JSONObject.quote(err ?: "")})", null
                    )
                }
            }
        }
        tts = engine

        setupWebView(engine)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { handleBack() }
        })

        web.loadUrl(startUrl())
    }

    private fun startUrl() = baseUrl + if (tvMode) "/tv" else "/"

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(engine: TtsEngine) {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        @Suppress("DEPRECATION")
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.allowFileAccess = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.textZoom = 100
        s.userAgentString = s.userAgentString + " EasyLoadApp/1.0" + if (tvMode) " EasyLoadTV" else ""
        CookieManager.getInstance().setAcceptCookie(true)
        web.setBackgroundColor(Color.parseColor("#0B1220"))
        web.isFocusable = true
        web.isFocusableInTouchMode = true

        web.addJavascriptInterface(AndroidBridge(this, engine), "AndroidApp")

        if (bridgeJs.isNotEmpty() && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, bridgeJs, setOf("*"))
            docStartInjected = true
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                loadFailed = false
                progress.visibility = View.VISIBLE
                if (!docStartInjected && bridgeJs.isNotEmpty()) view?.evaluateJavascript(bridgeJs, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                if (!loadFailed) {
                    hideOffline()
                    if (bridgeJs.isNotEmpty()) view?.evaluateJavascript(bridgeJs, null)   // safe: script ignores a 2nd run
                    // The TV page waits for a first "tap" before it speaks; a TV has no touch, so do it for it.
                    if (tvMode) view?.evaluateJavascript("try{document.dispatchEvent(new Event('click'))}catch(e){}", null)
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) showOffline()
            }

            @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
            override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                if (failingUrl != null && failingUrl.startsWith(baseUrl)) showOffline()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                return handleUrl(u)
            }

            @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return if (url == null) false else handleUrl(Uri.parse(url))
            }

            // Keeps a 24/7 TV alive if Chrome's renderer is killed by the system.
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                handler.post { recreate() }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
            }

            override fun onConsoleMessage(m: ConsoleMessage?): Boolean = true

            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                if (callback == null || params == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                try {
                    chooser.launch(params.createIntent())
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    Toast.makeText(this@MainActivity, "No file picker available on this device", Toast.LENGTH_LONG).show()
                }
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult?
            ): Boolean {
                if (result == null) return false
                if (isFinishing) { result.cancel(); return true }
                val input = EditText(this@MainActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setView(input)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
    }

    /** Stay inside the app for the Easy Load server; hand everything else (tel:, mailto:, wa.me ...) to Android. */
    private fun handleUrl(u: Uri): Boolean {
        val scheme = u.scheme ?: return false
        if (scheme == "http" || scheme == "https") {
            return if (u.host.equals(baseHost, ignoreCase = true)) false else openExternal(u)
        }
        if (scheme in listOf("blob", "data", "about", "javascript")) return false
        return openExternal(u)
    }

    private fun openExternal(u: Uri): Boolean {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    private fun showOffline() {
        loadFailed = true
        offlineMsg.text = "Make sure the PC server is running and this device is on the same network.\n\n$baseUrl\n\nTrying again automatically…"
        if (offline.visibility != View.VISIBLE) {
            offline.visibility = View.VISIBLE
            findViewById<Button>(R.id.btnRetry).requestFocus()
        }
        handler.removeCallbacks(retry)
        handler.postDelayed(retry, 6000)
    }

    private fun hideOffline() {
        offline.visibility = View.GONE
        handler.removeCallbacks(retry)
        web.requestFocus()
    }

    // ---------------- back / menu ----------------

    private fun handleBack() {
        if (offline.visibility != View.VISIBLE && !tvMode && web.canGoBack()) {
            web.goBack()
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastBack < 2000) {
            if (tvMode) showMenu() else finish()
            lastBack = 0
        } else {
            lastBack = now
            Toast.makeText(this, if (tvMode) "Press Back again for the menu" else "Press Back again to exit", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SETTINGS) {
            showMenu()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun showMenu() {
        AlertDialog.Builder(this)
            .setTitle("Easy Load")
            .setItems(arrayOf("Reload page", "Change server / mode", "Exit app")) { _, which ->
                when (which) {
                    0 -> web.loadUrl(startUrl())
                    1 -> openSetup()
                    2 -> finishAffinity()
                }
            }
            .show()
    }

    fun openSetup() {
        startActivity(Intent(this, SetupActivity::class.java))
    }

    // ---------------- helpers used by the JS bridge ----------------

    fun setVolumeRatio(r: Double) {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * r.coerceIn(0.0, 1.0)).toInt(), 0)
        } catch (e: Exception) { }
    }

    fun onFileSaved(name: String, saved: FileSaver.Saved?) {
        if (saved == null) {
            Toast.makeText(this, "Could not save $name", Toast.LENGTH_LONG).show()
            return
        }
        if (tvMode) {
            Toast.makeText(this, "Saved: ${saved.where}/$name", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("File saved")
            .setMessage("$name\n\n${saved.where}")
            .setPositiveButton("Open") { _, _ -> viewFile(saved) }
            .setNeutralButton("Share") { _, _ -> shareFile(saved) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun viewFile(f: FileSaver.Saved) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(f.uri, f.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "No app can open this file. It is saved in ${f.where}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareFile(f: FileSaver.Saved) {
        try {
            val i = Intent(Intent.ACTION_SEND).setType(f.mime)
                .putExtra(Intent.EXTRA_STREAM, f.uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share file"))
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot share this file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && tvMode) hideSystemBars()
    }

    // ---------------- lifecycle ----------------

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.onResume()
            web.evaluateJavascript("window.__elResume&&window.__elResume()", null)
        }
    }

    override fun onPause() {
        if (::web.isInitialized) web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        if (::web.isInitialized) {
            (web.parent as? android.view.ViewGroup)?.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }
}
