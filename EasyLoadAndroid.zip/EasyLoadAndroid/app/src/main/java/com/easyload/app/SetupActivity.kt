package com.easyload.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SetupActivity : AppCompatActivity() {

    private lateinit var etServer: EditText
    private lateinit var scanStatus: TextView
    private lateinit var results: LinearLayout
    private lateinit var btnScan: Button
    private lateinit var btnConnect: Button
    private lateinit var rgMode: RadioGroup
    private lateinit var cbBoot: CheckBox
    private var scanner: ServerScanner? = null
    private val found = LinkedHashSet<String>()
    private var firstRun = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)
        etServer = findViewById(R.id.etServer)
        scanStatus = findViewById(R.id.scanStatus)
        results = findViewById(R.id.results)
        btnScan = findViewById(R.id.btnScan)
        btnConnect = findViewById(R.id.btnConnect)
        rgMode = findViewById(R.id.rgMode)
        cbBoot = findViewById(R.id.cbBoot)

        val saved = Prefs.serverUrl(this)
        firstRun = saved == null
        etServer.setText(saved?.removePrefix("http://") ?: "")
        rgMode.check(
            when (Prefs.mode(this)) {
                "phone" -> R.id.rbPhone
                "tv" -> R.id.rbTv
                else -> R.id.rbAuto
            }
        )
        cbBoot.isChecked = Prefs.startOnBoot(this)

        btnScan.setOnClickListener { startScan() }
        btnConnect.setOnClickListener { connect() }
        etServer.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { connect(); true } else false
        }

        if (firstRun) startScan()
        btnScan.requestFocus()
    }

    private fun startScan() {
        scanner?.cancel()
        results.removeAllViews()
        found.clear()
        val port = Prefs.normalize(etServer.text.toString())?.let { Uri.parse(it).port }?.takeIf { it > 0 } ?: 3000
        scanStatus.text = "Scanning your network…"
        btnScan.isEnabled = false
        val s = ServerScanner()
        scanner = s
        s.scan(
            port,
            onFound = { addResult(it) },
            onProgress = { d, t -> scanStatus.text = "Scanning your network… $d / $t" },
            onDone = {
                btnScan.isEnabled = true
                scanStatus.text = if (found.isEmpty())
                    "No server found. Check that the PC server is running and this device is on the same Wi‑Fi / network, or type the IP address below."
                else
                    "Found ${found.size} server(s). Tap one to use it."
                if (firstRun && found.size == 1) connect()
            }
        )
    }

    private fun addResult(url: String) {
        if (!found.add(url)) return
        if (etServer.text.isNullOrBlank()) etServer.setText(url.removePrefix("http://"))
        val b = Button(this)
        b.text = "✅  " + url.removePrefix("http://")
        b.setTextColor(0xFFFFFFFF.toInt())
        b.setBackgroundResource(R.drawable.bg_btn_secondary)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (52 * resources.displayMetrics.density).toInt())
        lp.topMargin = (8 * resources.displayMetrics.density).toInt()
        b.layoutParams = lp
        b.setOnClickListener {
            etServer.setText(url.removePrefix("http://"))
            connect()
        }
        results.addView(b)
    }

    private fun connect() {
        val url = Prefs.normalize(etServer.text.toString())
        if (url == null) {
            etServer.error = "Enter the PC address, e.g. 192.168.1.10"
            return
        }
        btnConnect.isEnabled = false
        Thread {
            val ok = ServerScanner.check(url, 3500, false)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                btnConnect.isEnabled = true
                if (ok) save(url) else {
                    AlertDialog.Builder(this)
                        .setTitle("Cannot reach server")
                        .setMessage("$url did not answer.\nCheck the address, that the server is running, and that this device is on the same network.")
                        .setPositiveButton("Save anyway") { _, _ -> save(url) }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }.start()
    }

    private fun save(url: String) {
        Prefs.setServer(this, url)
        Prefs.setMode(
            this,
            when (rgMode.checkedRadioButtonId) {
                R.id.rbPhone -> "phone"
                R.id.rbTv -> "tv"
                else -> "auto"
            }
        )
        Prefs.setStartOnBoot(this, cbBoot.isChecked)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
    }

    override fun onDestroy() {
        scanner?.cancel()
        super.onDestroy()
    }
}
