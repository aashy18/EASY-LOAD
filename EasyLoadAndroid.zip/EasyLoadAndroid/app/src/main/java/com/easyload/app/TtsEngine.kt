package com.easyload.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Wraps Android's native text-to-speech. emit(id, "start"|"end"|"error", errorName). */
class TtsEngine(private val ctx: Context, private val emit: (Int, String, String?) -> Unit) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initDone = false
    private val waiting = ArrayList<() -> Unit>()

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            initDone = true
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                val t = tts
                try {
                    t?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                } catch (e: Exception) { }
                t?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { emit(idOf(utteranceId), "start", null) }
                    override fun onDone(utteranceId: String?) { emit(idOf(utteranceId), "end", null) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { emit(idOf(utteranceId), "error", "synthesis-failed") }
                    override fun onError(utteranceId: String?, errorCode: Int) { emit(idOf(utteranceId), "error", "synthesis-failed") }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) { emit(idOf(utteranceId), "error", "canceled") }
                })
            } else {
                Toast.makeText(ctx, "No text-to-speech engine found on this device", Toast.LENGTH_LONG).show()
            }
            val todo = ArrayList(waiting)
            waiting.clear()
            todo.forEach { it() }
        }
    }

    private fun idOf(s: String?): Int = s?.toIntOrNull() ?: -1

    private fun autoLocale(text: String): Locale {
        val arabic = text.any { it.code in 0x0600..0x06FF }
        return if (arabic) Locale("ar", "SA") else Locale.US
    }

    fun speak(id: Int, text: String, lang: String?, rate: Float, pitch: Float, voiceName: String?, flush: Boolean) {
        val job: () -> Unit = {
            val t = tts
            if (t == null || !ready) {
                emit(id, "error", "synthesis-unavailable")
            } else {
                var voiceSet = false
                if (!voiceName.isNullOrBlank()) {
                    try {
                        val v = t.voices?.firstOrNull { it.name == voiceName }
                        if (v != null) { t.setVoice(v); voiceSet = true }
                    } catch (e: Exception) { }
                }
                if (!voiceSet) {
                    val loc = if (lang.isNullOrBlank()) autoLocale(text) else Locale.forLanguageTag(lang.replace('_', '-'))
                    t.setLanguage(loc)
                }
                t.setSpeechRate(rate.coerceIn(0.3f, 2f))
                t.setPitch(pitch.coerceIn(0.5f, 2f))
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC.toString())
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f)
                }
                val r = t.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, params, id.toString())
                if (r != TextToSpeech.SUCCESS) emit(id, "error", "synthesis-failed")
            }
        }
        if (initDone) job() else waiting.add { job() }
    }

    fun stop() { try { tts?.stop() } catch (e: Exception) { } }

    fun voicesJson(): String {
        val t = tts
        if (t == null || !ready) return "[]"
        val arr = JSONArray()
        try {
            for (v in t.voices ?: emptySet()) {
                if (v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true) continue
                arr.put(
                    JSONObject()
                        .put("name", v.name)
                        .put("voiceURI", v.name)
                        .put("lang", v.locale.toLanguageTag())
                        .put("localService", !v.isNetworkConnectionRequired)
                        .put("default", false)
                )
            }
        } catch (e: Exception) { }
        return arr.toString()
    }

    fun shutdown() {
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
    }
}
