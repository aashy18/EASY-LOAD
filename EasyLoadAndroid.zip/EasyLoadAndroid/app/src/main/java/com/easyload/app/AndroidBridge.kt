package com.easyload.app

import android.util.Base64
import android.webkit.JavascriptInterface

/** Exposed to the web app as window.AndroidApp (the web code already calls these). */
class AndroidBridge(private val act: MainActivity, private val tts: TtsEngine) {

    // ---- used by the loading app (16-unit-voice.js) ----
    @JavascriptInterface fun speak(text: String?) {
        if (!text.isNullOrBlank()) tts.speak(-1, text, null, 0.9f, 0.95f, null, true)
    }
    @JavascriptInterface fun stopSpeaking() { tts.stop() }
    @JavascriptInterface fun setMaxVolume() { act.setVolumeRatio(1.0) }
    @JavascriptInterface fun maxVolume() { act.setVolumeRatio(1.0) }
    @JavascriptInterface fun setVolume(v: Double) { act.setVolumeRatio(v) }
    @JavascriptInterface fun setSpeechVolume(v: Double) { act.setVolumeRatio(v) }
    @JavascriptInterface fun changeServer() { act.runOnUiThread { act.openSetup() } }

    // ---- used by bridge.js ----
    @JavascriptInterface fun isTv(): Boolean = act.tvMode
    @JavascriptInterface fun version(): String = "1.0"
    @JavascriptInterface fun ttsSpeak(id: Int, text: String?, lang: String?, rate: Double, pitch: Double, voice: String?) {
        tts.speak(id, text ?: "", lang, rate.toFloat(), pitch.toFloat(), voice, false)
    }
    @JavascriptInterface fun ttsCancel() { tts.stop() }
    @JavascriptInterface fun ttsVoices(): String = tts.voicesJson()

    @JavascriptInterface fun saveFile(name: String?, mime: String?, base64: String?) {
        if (base64 == null) return
        val bytes = try { Base64.decode(base64, Base64.DEFAULT) } catch (e: Exception) { return }
        val saved = FileSaver.save(act, name ?: "download", mime, bytes)
        act.runOnUiThread { act.onFileSaved(name ?: "download", saved) }
    }
}
