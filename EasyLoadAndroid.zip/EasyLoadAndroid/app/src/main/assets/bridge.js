/* Injected by the Easy Load Android app before every page loads. */
(function () {
  if (window.__elBridge || !window.AndroidApp) return;
  window.__elBridge = true;

  /* ---- 1. File downloads (blob:/data: links) -> saved to Downloads/EasyLoad ---- */
  function isDl(a) {
    return a && a.tagName === 'A' && a.hasAttribute('download') && /^(blob:|data:)/i.test(a.href || '');
  }
  function sendFile(a) {
    try {
      var name = a.getAttribute('download') || 'download';
      var x = new XMLHttpRequest();
      x.open('GET', a.href, true);
      x.responseType = 'blob';
      x.onload = function () {
        var b = x.response, fr = new FileReader();
        fr.onloadend = function () {
          var d = String(fr.result || ''), i = d.indexOf(',');
          try { AndroidApp.saveFile(name, (b && b.type) || 'application/octet-stream', d.substring(i + 1)); } catch (e) {}
        };
        fr.readAsDataURL(b);
      };
      x.send();
    } catch (e) {}
  }
  var origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isDl(this)) { sendFile(this); return; }
    return origClick.apply(this, arguments);
  };
  var origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (e) {
    if (e && e.type === 'click' && isDl(this)) { sendFile(this); return true; }
    return origDispatch.apply(this, arguments);
  };
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (isDl(a)) { e.preventDefault(); sendFile(a); }
  }, true);

  /* ---- 2. Reconnect helper, called when the app returns to the foreground ---- */
  window.__elResume = function () {
    try { if (typeof socket !== 'undefined' && socket && !socket.connected) socket.connect(); } catch (e) {}
    try { document.dispatchEvent(new Event('visibilitychange')); } catch (e) {}
  };

  /* ---- 3. TV mode: route speechSynthesis to the device's native text-to-speech ---- */
  if (AndroidApp.isTv && AndroidApp.isTv() && AndroidApp.ttsSpeak) {
    var voices = [], map = {}, nid = 0;
    var load = function () { try { voices = JSON.parse(AndroidApp.ttsVoices() || '[]'); } catch (e) { voices = []; } };
    var listeners = {};
    var synth = {
      speaking: false, pending: false, paused: false, onvoiceschanged: null,
      getVoices: function () { load(); return voices; },
      speak: function (u) {
        var id = ++nid; map[id] = u; this.speaking = true;
        AndroidApp.ttsSpeak(id, String(u.text || ''), (u.voice && u.voice.lang) || u.lang || '',
          Number(u.rate) || 1, Number(u.pitch) || 1, (u.voice && u.voice.name) || '');
      },
      cancel: function () { try { AndroidApp.ttsCancel(); } catch (e) {} this.speaking = false; },
      pause: function () {}, resume: function () {},
      addEventListener: function (t, f) { (listeners[t] = listeners[t] || []).push(f); },
      removeEventListener: function (t, f) { listeners[t] = (listeners[t] || []).filter(function (x) { return x !== f; }); }
    };
    window.__elTtsEvent = function (id, type, err) {
      var u = map[id]; if (!u) return;
      if (type === 'start') { if (u.onstart) u.onstart({}); return; }
      delete map[id]; synth.speaking = false;
      if (type === 'end') { if (u.onend) u.onend({}); }
      else if (u.onerror) u.onerror({ error: err || 'synthesis-failed' });
    };
    function Utt(text) { this.text = text || ''; this.lang = ''; this.voice = null; this.rate = 1; this.pitch = 1; this.volume = 1;
      this.onstart = this.onend = this.onerror = null; }
    try { Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true }); } catch (e) { window.speechSynthesis = synth; }
    window.SpeechSynthesisUtterance = Utt;
  }
})();
