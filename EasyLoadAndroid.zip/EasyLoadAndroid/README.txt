EASY LOAD - ANDROID APP (phones + Android TV)

EASIEST WAY TO GET THE APK (no installation on your PC):
 1. Create a free account on github.com and make a new repository.
 2. Upload ALL files of this folder (including the hidden ".github" folder) to it.
 3. Open the "Actions" tab -> "Build Android APK" -> wait ~5 minutes.
 4. Open the finished run -> download "EasyLoad-apk" -> unzip -> app-release.apk

OR with Android Studio: File > Open this folder > Build > Build APK(s).

INSTALL: copy the APK to the phone / TV (USB stick, WhatsApp, or "Send Files to TV"), install it
(allow "install unknown apps").

FIRST START: the app finds your PC server automatically (port 3000). Or type the PC IP address.
 - Phone  -> opens the loading app.
 - Smart TV (Android TV / Google TV) -> opens the TV screen (/tv) automatically.
 - TV remote: press BACK twice for the menu (Reload / Change server / Exit).

PC TIPS: keep the server running, allow port 3000 in Windows Firewall, and give the PC a fixed IP in your router.
